import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import RoleSelectionPage from './AdminDashboard/pages/RoleSelectionPage';
import AdminLoginPage from './AdminDashboard/pages/AdminLoginPage';
import UserLoginPage from './UserDashboard/Components/UserLoginPage';
import RegisterPage from './AdminDashboard/pages/RegisterPage';
import AdminDashboard from './AdminDashboard/pages/AdminDashboard';
import UserManagement from './AdminDashboard/pages/UserManagement';
import UserDashboard from './UserDashboard/Components/UserDashboard';

function App() {
  return (
    <Router>
      <Routes>
        {/* Role Selection */}
        <Route path="/" element={<RoleSelectionPage />} />

        {/* Admin Routes */}
        <Route path="/admin-login" element={<AdminLoginPage />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/admin/user-management" element={<UserManagement />} />

        {/* User Routes */}
        <Route path="/user-login" element={<UserLoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/user-dashboard/*" element={<UserDashboard />} /> {/* Nested UserDashboard */}

        {/* Handle unmatched routes */}
        <Route path="*" element={<div>Page Not Found</div>} />
      </Routes>
    </Router>
  );
}

export default App;
