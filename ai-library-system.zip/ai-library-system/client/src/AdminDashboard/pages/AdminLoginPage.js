import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaEye, FaEyeSlash } from 'react-icons/fa'; // Import eye icons
import '../styles/AdminLoginPage.css'; // Updated to a unique CSS file for AdminLoginPage

function AdminLoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false); // State to toggle password visibility
  const navigate = useNavigate();

  // Admin credentials from environment variables
  const adminEmail = process.env.REACT_APP_ADMIN_EMAIL;
  const adminPassword = process.env.REACT_APP_ADMIN_PASSWORD;

  const handleLogin = () => {
    if (email === adminEmail && password === adminPassword) {
      // Redirect to Admin Dashboard
      navigate('/admin-dashboard');
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="admin-login-page">
      <div className="admin-login-form-container">
        <h1>ADMIN LOGIN</h1>
        <input 
          type="email" 
          placeholder="Email" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          className="admin-login-input-field"
        />
        
        {/* Password field with eye icon */}
        <div className="admin-login-password-container">
          <input 
            type={passwordVisible ? 'text' : 'password'} 
            placeholder="Password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            className="admin-login-input-field"
          />
          <span 
            className="admin-login-eye-icon" 
            onClick={() => setPasswordVisible(!passwordVisible)}
          >
            {passwordVisible ? <FaEyeSlash /> : <FaEye />}
          </span>
        </div>

        <button onClick={handleLogin} className="admin-login-button">
          Login
        </button>
      </div>
    </div>
  );
}

export default AdminLoginPage;
