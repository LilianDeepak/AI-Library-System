import React, { useState } from 'react';
import Sidebar from './Sidebar';
import UserManagement from './UserManagement';
import BookManagement from './BookManagement';
import BookInventory from './BookInventory';
import BorrowingReservation from './BorrowingReservation';

import ReportsAnalytics from './ReportsAnalytics';
import NotificationsAlerts from './NotificationsAlerts';

import '../styles/AdminDashboard.css';

function AdminDashboard() {
  const [selectedOption, setSelectedOption] = useState('userManagement');

  const renderContent = () => {
    switch (selectedOption) {
      case 'userManagement':
        return <UserManagement />;
      case 'bookManagement':
        return <BookManagement />;
      case 'bookInventory':
        return <BookInventory />;
      case 'borrowingReservation':
        return <BorrowingReservation />;
      
      case 'reportsAnalytics':
        return <ReportsAnalytics />;
      case 'notificationsAlerts':
        return <NotificationsAlerts />;
      
      default:
        return <div>Select an option from the sidebar</div>;
    }
  };

  return (
    <div className="admin-dashboard">
      <Sidebar setSelectedOption={setSelectedOption} />
      <div className="main-content">{renderContent()}</div>
    </div>
  );
}

export default AdminDashboard;
