import React from 'react';
import '../styles/Sidebar.css';
import { auth } from '../../services/firebase'; // Import Firebase authentication

function Sidebar({ setSelectedOption }) {
  const options = [
    { id: 'userManagement', label: 'User Management' },
    { id: 'bookManagement', label: 'Book Management' },
    { id: 'bookInventory', label: 'Book Inventory' },
    { id: 'borrowingReservation', label: 'Borrowing & Reservation' },
    { id: 'reportsAnalytics', label: 'Reports & Analytics' },
    { id: 'notificationsAlerts', label: 'Notifications & Alerts' },
  ];

  // Logout Function
  const handleLogout = () => {
    auth.signOut()
      .then(() => {
        alert("Successfully logged out!");
        window.location.href = "/"; // Redirect to the login page
      })
      .catch((error) => {
        console.error("Error logging out:", error);
        alert("Error logging out. Please try again.");
      });
  };

  return (
    <div className="sidebar">
      <ul>
        {options.map((option) => (
          <li key={option.id} onClick={() => setSelectedOption(option.id)}>
            {option.label}
          </li>
        ))}
        {/* Logout Option */}
        <li className="logout-option" onClick={handleLogout}>
          Logout
        </li>
      </ul>
    </div>
  );
}

export default Sidebar;
