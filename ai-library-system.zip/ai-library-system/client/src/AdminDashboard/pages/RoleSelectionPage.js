import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaUserAlt, FaUserShield } from 'react-icons/fa'; // Admin and User icons
import '../styles/RoleSelectionPage.css'; // Import CSS

function RoleSelectionPage() {
  const navigate = useNavigate();

  const handleRoleSelection = (role) => {
    if (role === 'admin') {
      navigate('/admin-login');
    } else if (role === 'user') {
      navigate('/user-login');
    }
  };

  return (
    <div className="role-selection-page">
      <h2 className="role-selection-title">WELCOME TO E-LIBRARY</h2>

      <div className="role-selection-container">
        <div className="role-selection-box" onClick={() => handleRoleSelection('admin')}>
          <FaUserShield className="role-selection-icon" />
          <h3 className="role-selection-role-name">Admin</h3>
        </div>
        <div className="role-selection-box" onClick={() => handleRoleSelection('user')}>
          <FaUserAlt className="role-selection-icon" />
          <h3 className="role-selection-role-name">User</h3>
        </div>
      </div>
    </div>
  );
}

export default RoleSelectionPage;
