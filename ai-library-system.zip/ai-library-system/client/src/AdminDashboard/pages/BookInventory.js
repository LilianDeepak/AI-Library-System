import React, { useState } from 'react';
import '../styles/BookInventory.css';

const BookInventory = () => {
  const [categories, setCategories] = useState([]);
  const [newCategory, setNewCategory] = useState('');
  const [subGenres, setSubGenres] = useState({});
  const [newSubGenre, setNewSubGenre] = useState({ category: '', subGenre: '' });

  // Add a new category
  const handleAddCategory = () => {
    if (newCategory && !categories.includes(newCategory)) {
      setCategories([...categories, newCategory]);
      setNewCategory('');
    } else {
      alert('Category already exists or is empty!');
    }
  };

  // Remove a category
  const handleRemoveCategory = (category) => {
    setCategories(categories.filter((cat) => cat !== category));
    const updatedSubGenres = { ...subGenres };
    delete updatedSubGenres[category];
    setSubGenres(updatedSubGenres);
  };

  // Add a sub-genre under a category
  const handleAddSubGenre = () => {
    if (newSubGenre.category && newSubGenre.subGenre) {
      setSubGenres((prev) => ({
        ...prev,
        [newSubGenre.category]: [
          ...(prev[newSubGenre.category] || []),
          newSubGenre.subGenre,
        ],
      }));
      setNewSubGenre({ category: '', subGenre: '' });
    } else {
      alert('Please select a category and provide a sub-genre name!');
    }
  };

  return (
    <div className="book-inventory-container">
      <h3 className="book-inventory-title">BOOK INVENTORY</h3>

      {/* Add Category */}
      <div className="book-inventory-category-section">
        <h4 className="book-inventory-subtitle">Manage Categories</h4>
        <input
          type="text"
          placeholder="New Category"
          value={newCategory}
          onChange={(e) => setNewCategory(e.target.value)}
          className="book-inventory-input"
        />
        <button onClick={handleAddCategory} className="book-inventory-button">
          Add Category
        </button>
        <ul className="book-inventory-category-list">
          {categories.map((category) => (
            <li key={category} className="book-inventory-category-item">
              {category}
              <button
                onClick={() => handleRemoveCategory(category)}
                className="book-inventory-remove-button"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Add Sub-genre */}
      <div className="book-inventory-sub-genre-section">
        <h4 className="book-inventory-subtitle">Manage Sub-genres</h4>
        <select
          value={newSubGenre.category}
          onChange={(e) => setNewSubGenre({ ...newSubGenre, category: e.target.value })}
          className="book-inventory-select"
        >
          <option value="">Select Category</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
        <input
          type="text"
          placeholder="New Sub-genre"
          value={newSubGenre.subGenre}
          onChange={(e) => setNewSubGenre({ ...newSubGenre, subGenre: e.target.value })}
          className="book-inventory-input"
        />
        <button onClick={handleAddSubGenre} className="book-inventory-button">
          Add Sub-genre
        </button>

        <div className="book-inventory-sub-genre-list">
          {categories.map((category) => (
            <div key={category} className="book-inventory-sub-genre-group">
              <h5 className="book-inventory-category-title">{category}</h5>
              <ul className="book-inventory-sub-genre-items">
                {(subGenres[category] || []).map((subGenre, index) => (
                  <li key={index} className="book-inventory-sub-genre-item">
                    {subGenre}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BookInventory;
