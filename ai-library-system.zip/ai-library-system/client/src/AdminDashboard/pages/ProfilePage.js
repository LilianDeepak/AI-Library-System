// client/src/pages/ProfilePage.js

import React from 'react';

function ProfilePage() {
  return (
    <div>
      <h2>User Profile</h2>
      <p>Welcome to your profile page.</p>
      {/* Add profile management features here */}
    </div>
  );
}

export default ProfilePage;
