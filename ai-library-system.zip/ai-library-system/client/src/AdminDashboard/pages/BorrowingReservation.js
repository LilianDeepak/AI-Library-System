import React, { useState, useEffect } from 'react';
import { db } from '../../services/firebase';
import { collection, getDocs } from 'firebase/firestore';
import '../styles/BorrowingReservation.css';

const BorrowingReservation = () => {
  const [borrowedBooks, setBorrowedBooks] = useState([]);

  // Fetch borrowed books and their details from Firestore
  useEffect(() => {
    const fetchBorrowedBooks = async () => {
      try {
        const usersCollection = collection(db, 'users');
        const querySnapshot = await getDocs(usersCollection);
        const borrowedBooksList = [];

        querySnapshot.forEach((doc) => {
          const userData = doc.data();
          if (userData.borrowedBooks) {
            userData.borrowedBooks.forEach((book) => {
              borrowedBooksList.push({
                ...book,
                borrower: userData.name || 'Unknown User', // Add borrower name
                borrowedDate: new Date(book.borrowedDate).toLocaleDateString(), // Format date
                dueDate: new Date(book.dueDate).toLocaleDateString(), // Format date
              });
            });
          }
        });

        setBorrowedBooks(borrowedBooksList);
      } catch (error) {
        console.error('Error fetching borrowed books:', error);
      }
    };

    fetchBorrowedBooks();
  }, []);

  return (
    <div className="borrowing-reservation">
      <h3>BORROWED BOOKS</h3>
      <table className="borrowing-reservation-table">
        <thead>
          <tr>
            <th>Book</th>
            <th>Borrower</th>
            <th>Borrowed On</th>
            <th>Due Date</th>
          </tr>
        </thead>
        <tbody>
          {borrowedBooks.length > 0 ? (
            borrowedBooks.map((book, index) => (
              <tr key={index}>
                <td>
                  <div className="book-details">
                    <p className="book-title">{book.title}</p>
                    <p className="book-author">by {book.author}</p>
                  </div>
                </td>
                <td>{book.borrower}</td>
                <td>{book.borrowedDate}</td>
                <td>{book.dueDate}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4">No books borrowed yet.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default BorrowingReservation;
