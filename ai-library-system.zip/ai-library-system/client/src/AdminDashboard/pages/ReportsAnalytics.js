import React, { useState, useEffect } from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import { db } from '../../services/firebase';
import { collection, getDocs } from 'firebase/firestore';
import '../styles/ReportsAnalytics.css';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const ReportsAnalytics = () => {
  const [totalUsers, setTotalUsers] = useState(0);
  const [newUsers, setNewUsers] = useState(0);
  const [professionData, setProfessionData] = useState({});
  const [borrowedBooksCount, setBorrowedBooksCount] = useState(0);
  const [mostBorrowedBook, setMostBorrowedBook] = useState('');
  const [dueBooks, setDueBooks] = useState(0);
  const [returnedBooks, setReturnedBooks] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const users = usersSnapshot.docs.map(doc => doc.data());

      setTotalUsers(users.length);
      const lastMonth = new Date();
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      setNewUsers(users.filter(user => new Date(user.createdAt) >= lastMonth).length);

      const professionCounts = {};
      users.forEach(user => {
        if (user.profession) {
          professionCounts[user.profession] = (professionCounts[user.profession] || 0) + 1;
        }
      });
      setProfessionData(professionCounts);

      const booksSnapshot = await getDocs(collection(db, 'books'));
      const books = booksSnapshot.docs.map(doc => doc.data());
      let borrowedBooks = books.filter(book => book.borrowedBy);

      setBorrowedBooksCount(borrowedBooks.length);

      const bookCountMap = {};
      borrowedBooks.forEach(book => {
        bookCountMap[book.title] = (bookCountMap[book.title] || 0) + 1;
      });

      setMostBorrowedBook(Object.keys(bookCountMap).reduce((a, b) => bookCountMap[a] > bookCountMap[b] ? a : b, ''));

      let dueBooksCount = 0;
      let returnedBooksCount = 0;
      borrowedBooks.forEach(book => {
        const dueDate = new Date(book.dueDate);
        if (dueDate < new Date()) {
          dueBooksCount++;
        }
        if (book.returned) {
          returnedBooksCount++;
        }
      });

      setDueBooks(dueBooksCount);
      setReturnedBooks(returnedBooksCount);
    };

    fetchData();
  }, []);

  // User Growth Chart (Total Users & New Users)
  const userGrowthChartData = {
    labels: ['Total Users', 'New Users (Last Month)'],
    datasets: [
      {
        label: 'Users',
        data: [totalUsers, newUsers],
        backgroundColor: ['#36A2EB', '#FF6384'],
      },
    ],
  };

  // Profession-based user distribution (Pie Chart)
  const professionChartData = {
    labels: Object.keys(professionData),
    datasets: [
      {
        data: Object.values(professionData),
        backgroundColor: ['#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#FF8C00'],
      },
    ],
  };

  // Borrowed Books Analytics (Bar Chart)
  const borrowedBooksChartData = {
    labels: ['Borrowed Books', 'Most Borrowed Book'],
    datasets: [
      {
        label: 'Count',
        data: [borrowedBooksCount, mostBorrowedBook ? 1 : 0], // Setting "1" if a book is borrowed
        backgroundColor: ['#FF6384', '#4CAF50'],
      },
    ],
  };

  // Due Books & Returned Books Analytics (Bar Chart)
  const dueReturnedBooksChartData = {
    labels: ['Due Books', 'Returned Books'],
    datasets: [
      {
        label: 'Count',
        data: [dueBooks, returnedBooks],
        backgroundColor: ['#FFCE56', '#36A2EB'],
      },
    ],
  };

  return (
    <div className="reports-analytics">
      <h3>REPORTS & ANALYTICS</h3>

      {/* User Growth Chart */}
      <div className="chart-container">
        <div className="chart-section">
          <h4>User Growth</h4>
          <Bar
            data={userGrowthChartData}
            options={{ responsive: true, plugins: { legend: { position: 'top' } } }}
          />
        </div>
      </div>

      {/* User Distribution by Profession */}
      <div className="chart-container">
        <div className="chart-section">
          <h4>Users by Profession</h4>
          <Pie
            data={professionChartData}
            options={{ responsive: true, plugins: { legend: { position: 'top' } } }}
          />
        </div>
      </div>

      {/* Borrowed Books Analytics */}
      <div className="chart-container">
        <div className="chart-section">
          <h4>Borrowed Books Analytics</h4>
          <Bar
            data={borrowedBooksChartData}
            options={{ responsive: true, plugins: { legend: { position: 'top' } } }}
          />
        </div>
      </div>

      {/* Due Books & Returned Books Analytics */}
      <div className="chart-container">
        <div className="chart-section">
          <h4>Due & Returned Books</h4>
          <Bar
            data={dueReturnedBooksChartData}
            options={{ responsive: true, plugins: { legend: { position: 'top' } } }}
          />
        </div>
      </div>
    </div>
  );
};

export default ReportsAnalytics;
