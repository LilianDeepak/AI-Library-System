// client/src/pages/AdminPanel.js
import React, { useState, useEffect } from 'react';

function AdminPanel() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await fetch('http://localhost:5000/api/users/admin/manageUsers');
      const data = await response.json();
      setUsers(data.users);
    };
    fetchUsers();
  }, []);

  return (
    <div>
      <h1>Admin Panel</h1>
      <h2>Manage Users</h2>
      <ul>
        {Object.keys(users).map((userId) => (
          <li key={userId}>{users[userId].username}</li>
        ))}
      </ul>
    </div>
  );
}

export default AdminPanel;
