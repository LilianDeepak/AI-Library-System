import React, { useState, useEffect } from 'react';
import { db } from '../../services/firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import '../styles/NotificationsAlerts.css';

const NotificationsAlerts = () => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const usersCollection = collection(db, 'users');

    // Listen for real-time updates in the users collection
    const unsubscribe = onSnapshot(usersCollection, (snapshot) => {
      const notificationList = [];
      const now = new Date();

      snapshot.forEach((doc) => {
        const userData = doc.data();

        // New User Registered Notification
        if (userData.createdAt) {
          const createdAt = userData.createdAt.toDate();
          if ((now - createdAt) / (1000 * 60 * 60) < 24) { // Only keep notifications within 24 hours
            notificationList.push({
              message: `🎉 New user registered: ${userData.name}`,
              timestamp: createdAt.toLocaleString(),
            });
          }
        }

        // Borrowed Books Notifications
        if (userData.borrowedBooks) {
          userData.borrowedBooks.forEach((book) => {
            const borrowedDate = new Date(book.borrowedDate);
            if ((now - borrowedDate) / (1000 * 60 * 60) < 24) { // Keep notifications within 24 hours
              notificationList.push({
                message: `📖 '${book.title}' borrowed by ${userData.name}`,
                timestamp: borrowedDate.toLocaleString(),
              });
            }

            // Due Date Notifications
            const dueDate = new Date(book.dueDate);
            const daysLeft = Math.ceil((dueDate - now) / (1000 * 60 * 60 * 24));

            if (daysLeft === 0 || daysLeft === 1) { // Show only due soon notifications within 1 day
              notificationList.push({
                message: `⚠️ Due soon! '${book.title}' is due in ${daysLeft} days.`,
                timestamp: now.toLocaleString(),
              });
            }

            // Returned Books Notifications (if implemented)
            if (book.returnedDate) {
              const returnedDate = new Date(book.returnedDate);
              if ((now - returnedDate) / (1000 * 60 * 60) < 24) { // Only keep notifications within 24 hours
                notificationList.push({
                  message: `✅ '${book.title}' returned by ${userData.name}`,
                  timestamp: returnedDate.toLocaleString(),
                });
              }
            }
          });
        }
      });

      // Sort notifications by timestamp (newest first)
      notificationList.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      setNotifications(notificationList);
    });

    return () => unsubscribe(); // Cleanup listener on unmount
  }, []);

  return (
    <div className="notifications-alerts">
      <h3>NOTIFICATIONS & ALERTS</h3>
      {notifications.length === 0 ? (
        <p>No recent notifications.</p>
      ) : (
        <ul className="notifications-list">
          {notifications.map((notification, index) => (
            <li key={index} className="notification-item">
              <p>{notification.message}</p>
              <span className="timestamp">{notification.timestamp}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default NotificationsAlerts;
