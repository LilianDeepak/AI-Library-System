import React, { useState } from 'react';
import { auth, db } from '../../services/firebase'; // Import Firestore and Firebase Auth
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { setDoc, doc } from 'firebase/firestore'; // Use setDoc for direct control over the document ID
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify'; // Import Toastify functions
import 'react-toastify/dist/ReactToastify.css';  // Import Toastify styles
import '../styles/RegisterPage.css';  // Correct import

// Import eye icons for toggling password visibility
import { FaEye, FaEyeSlash } from 'react-icons/fa';

function RegisterPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');  // Confirm password field
  const [passwordVisible, setPasswordVisible] = useState(false); // State to toggle password visibility
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false); // State to toggle confirm password visibility
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async () => {
    if (!name || !email || !password || !confirmPassword) {
      setError('All fields are required');
      toast.error('Please fill out all fields', { position: "top-right", autoClose: 5000 });
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      toast.error('Passwords do not match', { position: "top-right", autoClose: 5000 });
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Create a new user with email and password
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);

      // Extract user details
      const user = userCredential.user;

      // Add the user's details to the Firestore 'users' collection with user.uid as the document ID
      const userDocRef = doc(db, 'users', user.uid);
      await setDoc(userDocRef, {
        uid: user.uid,
        name: name,
        email: email,
        role: 'user', // Set role as 'user'
        createdAt: new Date(),
      });

      // Show success toast with green color (default for success)
      toast.success('Registration Successful!', {
        position: "top-right",
        autoClose: 5000,
      });

      // Redirect to the User Login page after success toast
      setTimeout(() => {
        navigate('/user-login');
      }, 5000);
      
    } catch (error) {
      // Show error toast
      toast.error('Error: ' + error.message, {
        position: "top-right",
        autoClose: 5000,
      });
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-page">
      <div className="form-container">
        <h1>REGISTER</h1>
        {error && <p className="register-page-error-message">{error}</p>}

        {/* Name Input */}
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="register-page-input-field"
        />

        {/* Email Input */}
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="register-page-input-field"
        />

        {/* Password field with eye icon */}
        <div className="register-page-password-container">
          <input
            type={passwordVisible ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="register-page-input-field"
          />
          <span
            className="register-page-eye-icon"
            onClick={() => setPasswordVisible(!passwordVisible)}
          >
            {passwordVisible ? <FaEyeSlash /> : <FaEye />}
          </span>
        </div>

        {/* Confirm Password field with eye icon */}
        <div className="register-page-password-container">
          <input
            type={confirmPasswordVisible ? 'text' : 'password'}
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="register-page-input-field"
          />
          <span
            className="register-page-eye-icon"
            onClick={() => setConfirmPasswordVisible(!confirmPasswordVisible)}
          >
            {confirmPasswordVisible ? <FaEyeSlash /> : <FaEye />}
          </span>
        </div>

        {/* Register Button */}
        <button
          onClick={handleRegister}
          disabled={loading}
          className={`register-page-register-button ${loading ? 'loading' : ''}`}
        >
          {loading ? 'Registering...' : 'Register'}
        </button>

        {/* Sign-In Text */}
        <p className="register-page-sign-in-text">
          Already signed up? <span onClick={() => navigate('/user-login')}>Sign In</span>
        </p>
      </div>
      
      {/* ToastContainer for showing the toast messages */}
      <ToastContainer />
    </div>
  );
}

export default RegisterPage;
