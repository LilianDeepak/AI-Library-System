import React, { useState, useEffect } from 'react';
import { db, auth } from '../../services/firebase'; // Firebase setup import
import { collection, getDocs, query, orderBy, limit, startAfter, doc, updateDoc, deleteDoc, addDoc } from 'firebase/firestore'; // Firestore functions
import { createUserWithEmailAndPassword, updateEmail, updatePassword, getAuth } from 'firebase/auth'; // Firebase Authentication functions
import '../styles/UserManagement.css'; // Import the CSS for styles

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [lastVisible, setLastVisible] = useState(null); // Keeps track of the last document for pagination
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);

  // Add new user states
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState('user');
  const [newUserPassword, setNewUserPassword] = useState('');

  // Edit user states
  const [editingUser, setEditingUser] = useState(null);
  const [editedName, setEditedName] = useState('');
  const [editedEmail, setEditedEmail] = useState('');
  const [editedRole, setEditedRole] = useState('');
  const [editedPassword, setEditedPassword] = useState('');

  // Fetch the users data from Firestore
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);  // Ensure loading state is set to true when fetching data
      const usersCollectionRef = collection(db, 'users');
      const userQuery = query(
        usersCollectionRef,
        orderBy('createdAt'),
        limit(5) // Only fetch 5 users per page
      );

      const querySnapshot = await getDocs(userQuery);
      const usersList = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));

      setUsers(usersList);
      setLoading(false);

      const lastVisibleDoc = querySnapshot.docs[querySnapshot.docs.length - 1];
      setLastVisible(lastVisibleDoc); // Update the last visible document for pagination
    };

    fetchUsers();
  }, [page]);

  // Handle the search functionality
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  // Filter users based on the search term
  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle pagination for next page
  const handleNextPage = async () => {
    setLoading(true);
    const usersCollectionRef = collection(db, 'users');
    const nextQuery = query(
      usersCollectionRef,
      orderBy('createdAt'),
      startAfter(lastVisible), // Start from the last fetched document
      limit(5) // Fetch 5 more users
    );

    const querySnapshot = await getDocs(nextQuery);
    const usersList = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
    }));

    setUsers(usersList);
    const lastVisibleDoc = querySnapshot.docs[querySnapshot.docs.length - 1];
    setLastVisible(lastVisibleDoc); // Update the last visible document
    setPage(page + 1); // Increment the page number
    setLoading(false);
  };

  // Handle pagination for previous page
  const handlePreviousPage = async () => {
    if (page > 1) {
      setLoading(true);
      const usersCollectionRef = collection(db, 'users');
      const prevQuery = query(
        usersCollectionRef,
        orderBy('createdAt'),
        limit(5)
      );

      const querySnapshot = await getDocs(prevQuery);
      const usersList = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));

      setUsers(usersList);
      setPage(page - 1); // Decrement the page number
      setLoading(false);
    }
  };

  const handleAddUser = async () => {
    if (!newUserName || !newUserEmail || !newUserPassword) {
      alert('Please fill in all fields!');
      return;
    }
  
    try {
      // Step 1: Create the user in Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, newUserEmail, newUserPassword);
      const user = userCredential.user; // The created user
  
      // Step 2: Store the user in Firestore
      const usersCollectionRef = collection(db, 'users');
      await addDoc(usersCollectionRef, {
        uid: user.uid, // Store the Firebase Authentication UID
        name: newUserName,
        email: newUserEmail,
        role: newUserRole,
        createdAt: new Date(),
      });
  
      // Clear the input fields after successful addition
      setNewUserName('');
      setNewUserEmail('');
      setNewUserRole('user');
      setNewUserPassword('');
  
      // Optionally, update the user list without fetching all users again
      setUsers(prevUsers => [...prevUsers, { name: newUserName, email: newUserEmail, role: newUserRole }]);
      alert('User added successfully!');
    } catch (error) {
      console.error('Error adding user:', error);
      alert('Error adding user!');
    }
  };

  // Edit User
  const handleEditUser = (userId) => {
    const userToEdit = users.find(user => user.id === userId);
    setEditingUser(userToEdit);
    setEditedName(userToEdit.name);
    setEditedEmail(userToEdit.email);
    setEditedRole(userToEdit.role);
    setEditedPassword(userToEdit.password);
  };

  const handleEditSubmit = async () => {
    if (!editedName || !editedEmail || !editedPassword) {
      alert('Please fill in all fields!');
      return;
    }
  
    try {
      const userDocRef = doc(db, 'users', editingUser.id);  // Firestore document reference
      await updateDoc(userDocRef, {
        name: editedName,
        email: editedEmail,
        role: editedRole,
        password: editedPassword,
      });
  
      // Update Firebase Auth details (if necessary)
      const auth = getAuth();
      const user = auth.currentUser;
  
      if (user) {
        await updateEmail(user, editedEmail); // Update email in Firebase Authentication
        await updatePassword(user, editedPassword); // Update password in Firebase Authentication
      }
  
      alert('User details updated successfully!');
      setEditingUser(null); // Close the edit form
    } catch (error) {
      console.error('Error editing user:', error);
      alert('Error updating user!');
    }
  };

  // Delete User
  const handleDeleteUser = async (userId) => {
    try {
      // Check if users array is defined and has elements
      if (!Array.isArray(users) || users.length === 0) {
        console.error('No users to delete');
        return;
      }
  
      // Find user index in the array
      const userIndex = users.findIndex(user => user.id === userId);
      if (userIndex === -1) {
        console.error('User not found!');
        return;
      }
  
      // Proceed to delete the user from Firestore
      const userDocRef = doc(db, 'users', userId);
      await deleteDoc(userDocRef);
  
      // Update local state after deletion
      setUsers(prevUsers => prevUsers.filter(user => user.id !== userId));
  
      alert('User deleted successfully!');
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Error deleting user!');
    }
  };

  // Check if pagination controls should be displayed (only if there are more than 5 users)
  const showPagination = users.length > 5;

  return (
    <div>
      <h3 className="user-management-title">USER MANAGEMENT</h3>

      {/* Add User Form */}
      <div className="user-management-add-user">
        <h4>ADD NEW USER</h4>
        <input
          type="text"
          placeholder="Name"
          value={newUserName}
          onChange={(e) => setNewUserName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Email"
          value={newUserEmail}
          onChange={(e) => setNewUserEmail(e.target.value)}
        />
        <select
          value={newUserRole}
          onChange={(e) => setNewUserRole(e.target.value)}
        >
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>
        <input
          type="password"
          placeholder="Password"
          value={newUserPassword}
          onChange={(e) => setNewUserPassword(e.target.value)}
        />
        <button onClick={handleAddUser}>Add User</button>
      </div>

      {/* Search Bar */}
      <div className="user-management-search-bar">
        <input
          type="text"
          placeholder="Search users by name, email, or role"
          value={searchTerm}
          onChange={handleSearch}
        />
      </div>

      {/* User List Table */}
      <table className="user-management-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Registered Date</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr><td colSpan="5">Loading...</td></tr>
          ) : filteredUsers.length === 0 ? (
            <tr><td colSpan="5">No data available</td></tr>
          ) : (
            filteredUsers.map((user) => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>
                  {user.createdAt && user.createdAt.seconds
                    ? new Date(user.createdAt.seconds * 1000).toLocaleDateString()
                    : 'N/A'}
                </td>
                <td>{user.role}</td>
                <td>
                  <button onClick={() => handleEditUser(user.id)}>Edit</button>
                  <button onClick={() => handleDeleteUser(user.id)}>Delete</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* Pagination */}
      {showPagination && (
        <div className="user-management-pagination">
          <button onClick={handlePreviousPage} disabled={page === 1}>
            Previous
          </button>
          <button onClick={handleNextPage}>Next</button>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="user-management-edit-modal">
          <h4>Edit User</h4>
          <input
            type="text"
            placeholder="Name"
            value={editedName}
            onChange={(e) => setEditedName(e.target.value)}
          />
          <input
            type="email"
            placeholder="Email"
            value={editedEmail}
            onChange={(e) => setEditedEmail(e.target.value)}
          />
          <select
            value={editedRole}
            onChange={(e) => setEditedRole(e.target.value)}
          >
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
          <input
            type="password"
            placeholder="Password"
            value={editedPassword}
            onChange={(e) => setEditedPassword(e.target.value)}
          />
          <button onClick={handleEditSubmit}>Save Changes</button>
          <button onClick={() => setEditingUser(null)}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
