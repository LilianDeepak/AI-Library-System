import React, { useState, useEffect } from 'react';
import { db } from '../../services/firebase';
import {
  collection,
  addDoc,
  deleteDoc,
  updateDoc,
  doc,
  getDocs,
  query,
  orderBy,
} from 'firebase/firestore';
import '../styles/BookManagement.css';

const BookManagement = () => {
  const [books, setBooks] = useState([]);
  const [borrowedBookIds, setBorrowedBookIds] = useState([]);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    genre: '',
    description: '',
    imageUrl: '',
    driveLink: '',
    status: 'available',
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [editingBook, setEditingBook] = useState(null);

  // Fetch borrowed books from all users
  const fetchBorrowedBooks = async () => {
    const usersCollection = collection(db, 'users');
    const querySnapshot = await getDocs(usersCollection);

    const borrowedBooks = [];
    querySnapshot.forEach((doc) => {
      const userData = doc.data();
      if (userData.borrowedBooks) {
        userData.borrowedBooks.forEach((book) => {
          borrowedBooks.push(book.id);
        });
      }
    });
    setBorrowedBookIds(borrowedBooks);
  };

  // Fetch books from Firestore
  useEffect(() => {
    const fetchBooks = async () => {
      const booksCollection = collection(db, 'books');
      const booksQuery = query(booksCollection, orderBy('title'));
      const querySnapshot = await getDocs(booksQuery);

      const booksList = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setBooks(booksList);
    };

    fetchBooks();
    fetchBorrowedBooks(); // Fetch borrowed book IDs
  }, []);

  // Determine the status dynamically
  const getBookStatus = (bookId) => {
    return borrowedBookIds.includes(bookId) ? 'Not Available' : 'Available';
  };

  // Add a new book
  const handleAddBook = async () => {
    if (
      !newBook.title ||
      !newBook.author ||
      !newBook.genre ||
      !newBook.description ||
      !newBook.imageUrl ||
      !newBook.driveLink
    ) {
      alert('Please fill in all fields!');
      return;
    }

    try {
      const booksCollection = collection(db, 'books');
      const docRef = await addDoc(booksCollection, newBook);
      setBooks([...books, { id: docRef.id, ...newBook }]);
      setNewBook({
        title: '',
        author: '',
        genre: '',
        description: '',
        imageUrl: '',
        driveLink: '',
        status: 'available',
      });
      alert('Book added successfully!');
    } catch (error) {
      console.error('Error adding book:', error);
      alert('Error adding book!');
    }
  };

  // Delete a book
  const handleDeleteBook = async (bookId) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      try {
        await deleteDoc(doc(db, 'books', bookId));
        setBooks(books.filter((book) => book.id !== bookId));
        alert('Book deleted successfully!');
      } catch (error) {
        console.error('Error deleting book:', error);
        alert('Error deleting book!');
      }
    }
  };

  // Edit a book
  const handleEditBook = (book) => {
    setEditingBook(book);
  };

  const handleEditSubmit = async () => {
    if (
      !editingBook.title ||
      !editingBook.author ||
      !editingBook.genre ||
      !editingBook.description ||
      !editingBook.imageUrl ||
      !editingBook.driveLink
    ) {
      alert('Please fill in all fields!');
      return;
    }

    try {
      await updateDoc(doc(db, 'books', editingBook.id), editingBook);
      setBooks(books.map((book) => (book.id === editingBook.id ? editingBook : book)));
      setEditingBook(null);
      alert('Book updated successfully!');
    } catch (error) {
      console.error('Error updating book:', error);
      alert('Error updating book!');
    }
  };

  // Filter books based on search term
  const filteredBooks = books.filter(
    (book) =>
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.genre.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="book-management-container">
      <h3>BOOK MANAGEMENT</h3>

      {/* Add New Book */}
      <div className="book-management-add-book">
        <h4>Add New Book</h4>
        <input
          type="text"
          placeholder="Title"
          value={newBook.title}
          onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
        />
        <input
          type="text"
          placeholder="Author"
          value={newBook.author}
          onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
        />
        <textarea
          placeholder="Description"
          value={newBook.description}
          onChange={(e) => setNewBook({ ...newBook, description: e.target.value })}
          rows="4"
        />
        <input
          type="text"
          placeholder="Genre"
          value={newBook.genre}
          onChange={(e) => setNewBook({ ...newBook, genre: e.target.value })}
        />
        <input
          type="text"
          placeholder="Image URL"
          value={newBook.imageUrl}
          onChange={(e) => setNewBook({ ...newBook, imageUrl: e.target.value })}
        />
        <input
          type="text"
          placeholder="Drive Link"
          value={newBook.driveLink}
          onChange={(e) => setNewBook({ ...newBook, driveLink: e.target.value })}
        />
        <button onClick={handleAddBook}>Add Book</button>
      </div>

      {/* Search Bar */}
      <div className="book-management-search-bar">
        <input
          type="text"
          placeholder="Search by title, author, genre, or status"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Book List */}
      <table className="book-management-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredBooks.map((book) => (
            <tr key={book.id}>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.genre}</td>
              <td>{getBookStatus(book.id)}</td>
              <td>
                <button onClick={() => handleEditBook(book)}>Edit</button>
                <button onClick={() => handleDeleteBook(book.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Edit Book Modal */}
      {editingBook && (
        <div className="book-management-edit-book-modal">
          <h4>Edit Book</h4>
          <input
            type="text"
            placeholder="Title"
            value={editingBook.title}
            onChange={(e) => setEditingBook({ ...editingBook, title: e.target.value })}
          />
          <input
            type="text"
            placeholder="Author"
            value={editingBook.author}
            onChange={(e) => setEditingBook({ ...editingBook, author: e.target.value })}
          />
          <textarea
            placeholder="Description"
            value={editingBook.description}
            onChange={(e) => setEditingBook({ ...editingBook, description: e.target.value })}
            rows="4"
          />
          <input
            type="text"
            placeholder="Genre"
            value={editingBook.genre}
            onChange={(e) => setEditingBook({ ...editingBook, genre: e.target.value })}
          />
          <input
            type="text"
            placeholder="Image URL"
            value={editingBook.imageUrl}
            onChange={(e) => setEditingBook({ ...editingBook, imageUrl: e.target.value })}
          />
          <input
            type="text"
            placeholder="Drive Link"
            value={editingBook.driveLink}
            onChange={(e) => setEditingBook({ ...editingBook, driveLink: e.target.value })}
          />
          <button onClick={handleEditSubmit}>Save</button>
          <button onClick={() => setEditingBook(null)}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default BookManagement;
