import React, { useEffect, useState } from 'react';
import axios from 'axios';

const HomePage = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch books data from the API
    axios
      .get('http://localhost:5000/api/books')
      .then((response) => {
        // Check if the response is an array
        if (Array.isArray(response.data)) {
          setBooks(response.data);  // Set the books data to state
        } else {
          console.error('Books data is not an array:', response.data);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching books', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!Array.isArray(books)) {
    return <div>Error: Books data is not an array</div>;
  }

  return (
    <div>
      <h1>Books</h1>
      <ul>
        {books.map((book, index) => (
          <li key={index}>
            <h2>{book.title}</h2>
            <p>{book.author}</p>
            <p>{book.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default HomePage;
