import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '../../services/firebase';
import { collection, getDocs } from 'firebase/firestore';
import '../Styles/BookBrowsing.css';

function BookBrowsing() {
  const [search, setSearch] = useState('');
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  const [genres, setGenres] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [loading, setLoading] = useState(true); // Add loading state
  const navigate = useNavigate();

  // Fetch books and genres from Firestore
  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'books'));
        const bookData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setBooks(bookData);
        setFilteredBooks(bookData);

        // Extract unique genres from the books
        const allGenres = ['All', ...new Set(bookData.map((book) => book.genre))];
        setGenres(allGenres);
      } catch (error) {
        console.error('Error fetching books:', error);
      } finally {
        setLoading(false); // Set loading to false after data is fetched
      }
    };
    fetchBooks();
  }, []);

  const handleSearch = () => {
    const filtered = books.filter((book) =>
      book.title.toLowerCase().includes(search.toLowerCase())
    );
    setFilteredBooks(filtered);
  };

  const handleGenreClick = (genre) => {
    setSelectedGenre(genre);
    if (genre === 'All') {
      setFilteredBooks(books);
    } else {
      const filtered = books.filter((book) => book.genre === genre);
      setFilteredBooks(filtered);
    }
  };

  const handleBookClick = (bookId) => {
    navigate(`/user-dashboard/book/${bookId}`); // Navigate to book details page
  };

  if (loading) {
    return <div className="loading">Loading books...</div>;
  }

  return (
    <div className="user-dashboard-browsing">
      <h2 className="browsing-title">Browse Books</h2>
      <div className="search-container">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
          placeholder="Search books"
        />
        <button onClick={handleSearch} className="search-btn">
          Search
        </button>
      </div>

      {/* Genre Filters */}
      <div className="genre-filters">
        {genres.map((genre) => (
          <button
            key={genre}
            className={`genre-filter ${selectedGenre === genre ? 'active' : ''}`}
            onClick={() => handleGenreClick(genre)}
          >
            {genre}
          </button>
        ))}
      </div>

      <div className="book-list">
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <div
              key={book.id}
              className="book-item"
              onClick={() => handleBookClick(book.id)}
            >
              <div className="book-image-container">
                <img
                  src={book.imageUrl || 'https://via.placeholder.com/100x130'}
                  alt={book.title}
                  className="book-image"
                />
              </div>
              <h3>{book.title}</h3>
              <p>{book.author}</p>
            </div>
          ))
        ) : (
          <div className="no-results">No books found for the selected genre</div>
        )}
      </div>
    </div>
  );
}

export default BookBrowsing;
