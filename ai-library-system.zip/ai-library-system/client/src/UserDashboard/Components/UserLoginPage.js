import React, { useState } from 'react';
import { auth } from '../../services/firebase'; // Your Firebase setup
import { signInWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify'; // Import Toastify functions
import 'react-toastify/dist/ReactToastify.css'; // Import Toastify styles
import { FaEye, FaEyeSlash } from 'react-icons/fa'; // Import eye icons
import '../Styles/UserLoginPage.css'; // Correct import

function UserLoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false); // State to toggle password visibility
  const navigate = useNavigate();

  const handleLogin = () => {
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Redirect to User Dashboard's default section (profile)
        toast.success('Login Successful!', { position: 'top-right', autoClose: 5000 });
        navigate('/user-dashboard/profile');
      })
      .catch((error) => {
        toast.error('Error: ' + error.message, { position: 'top-right', autoClose: 5000 });
      });
  };

  const handleSignUpRedirect = () => {
    navigate('/register'); // Redirect to Register Page
  };

  return (
    <div className="user-login-page">
      <div className="user-login-form-container">
        <h1 className="user-login-title">NEW USER</h1>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="user-login-input-field"
        />

        {/* Password field with eye icon */}
        <div className="user-login-password-container">
          <input
            type={passwordVisible ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="user-login-input-field"
          />
          <span
            className="user-login-eye-icon"
            onClick={() => setPasswordVisible(!passwordVisible)}
          >
            {passwordVisible ? <FaEyeSlash /> : <FaEye />}
          </span>
        </div>

        <button onClick={handleLogin} className="user-login-button">
          Login
        </button>
        <p>
          Don't have an account?
          <button onClick={handleSignUpRedirect} className="user-login-signup-redirect">
            Sign Up
          </button>
        </p>
      </div>

      {/* ToastContainer for showing the toast messages */}
      <ToastContainer />
    </div>
  );
}

export default UserLoginPage;
