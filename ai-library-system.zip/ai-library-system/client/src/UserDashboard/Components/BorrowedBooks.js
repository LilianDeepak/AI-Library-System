import React, { useState, useEffect } from "react";
import { db, auth } from "../../services/firebase"; // Firebase setup
import { doc, getDoc, updateDoc } from "firebase/firestore"; // Firestore functions
import "../Styles/BorrowedBooks.css";

function BorrowedBooks() {
  const [borrowedBooks, setBorrowedBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBorrowedBooks = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          alert("Please log in to view borrowed books.");
          return;
        }

        const userDoc = doc(db, "users", user.uid);
        const userSnapshot = await getDoc(userDoc);

        if (userSnapshot.exists()) {
          const userData = userSnapshot.data();
          setBorrowedBooks(userData.borrowedBooks || []);
        }
      } catch (err) {
        console.error("Error fetching borrowed books:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchBorrowedBooks();
  }, []);

  const handleReadBook = async (driveLink, book) => {
    if (!driveLink) {
      alert("No drive link available for this book.");
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      alert("Please log in to save your reading history.");
      return;
    }

    try {
      // Open the drive link in a new tab
      window.open(driveLink, "_blank", "noopener,noreferrer");

      const userDocRef = doc(db, "users", user.uid);
      const userSnapshot = await getDoc(userDocRef);

      if (userSnapshot.exists()) {
        const userData = userSnapshot.data();
        const readingHistory = userData.readingHistory || [];

        // Check if the book is already in the reading history
        const isAlreadyRead = readingHistory.some((b) => b.id === book.id);
        if (isAlreadyRead) {
          console.log("Book already in reading history.");
          return;
        }

        // Add the book to the reading history
        const updatedReadingHistory = [
          ...readingHistory,
          {
            id: book.id,
            title: book.title,
            author: book.author,
            imageUrl: book.imageUrl,
            readDate: new Date().toISOString(),
          },
        ];

        // Update Firestore
        await updateDoc(userDocRef, { readingHistory: updatedReadingHistory });
        console.log("Book added to reading history!");
      }
    } catch (err) {
      console.error("Error adding to reading history:", err);
    }
  };

  const handleReturnBook = async (bookId) => {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const updatedBooks = borrowedBooks.filter((book) => book.id !== bookId);
      const userDoc = doc(db, "users", user.uid);
      await updateDoc(userDoc, { borrowedBooks: updatedBooks });
      setBorrowedBooks(updatedBooks);
      alert("Book returned successfully!");
    } catch (err) {
      console.error("Error returning the book:", err);
    }
  };

  const handleExtendDueDate = async (bookId) => {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const updatedBooks = borrowedBooks.map((book) => {
        if (book.id === bookId) {
          const newDueDate = new Date();
          newDueDate.setDate(newDueDate.getDate() + 30); // Extend by 30 days
          return { ...book, dueDate: newDueDate.toISOString() };
        }
        return book;
      });

      const userDoc = doc(db, "users", user.uid);
      await updateDoc(userDoc, { borrowedBooks: updatedBooks });
      setBorrowedBooks(updatedBooks);
      alert("Due date extended by 1 month!");
    } catch (err) {
      console.error("Error extending the due date:", err);
    }
  };

  if (loading) {
    return <div>Loading borrowed books...</div>;
  }

  return (
    <div className="user-dashboard-borrowed">
      <h2 className="borrowed-title">Borrowed Books</h2>
      <div className="book-list">
        {borrowedBooks.length > 0 ? (
          borrowedBooks.map((book) => (
            <div key={book.id} className="book-item">
              <div className="book-image-container">
                <img
                  src={book.imageUrl || "https://via.placeholder.com/130x200"}
                  alt={book.title}
                  className="book-image"
                />
              </div>
              <h3>{book.title}</h3>
              <p>Due Date: {new Date(book.dueDate).toLocaleDateString()}</p>
              <button
                className="read-btn"
                onClick={() => handleReadBook(book.driveLink, book)}
              >
                Read
              </button>
              <button
                className="return-btn"
                onClick={() => handleReturnBook(book.id)}
              >
                Return
              </button>
              <button
                className="extend-btn"
                onClick={() => handleExtendDueDate(book.id)}
              >
                Extend
              </button>
            </div>
          ))
        ) : (
          <div>No borrowed books found.</div>
        )}
      </div>
    </div>
  );
}

export default BorrowedBooks;
