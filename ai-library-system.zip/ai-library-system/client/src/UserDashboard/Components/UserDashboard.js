import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import UserSidebar from './UserSidebar'; // Import the sidebar component
import UserProfile from './UserProfile';
import BookBrowsing from './BookBrowsing';
import BorrowedBooks from './BorrowedBooks';
import Wishlist from './Wishlist';
import ReadingHistory from './ReadingHistory';
import Notifications from './Notifications';
import BookDetails from './BookDetails'; // Import the BookDetails component
import { auth } from '../../services/firebase'; // Firebase Auth
import { doc, getDoc } from 'firebase/firestore'; // Firestore functions
import { db } from '../../services/firebase'; // Firestore database instance
import '../Styles/UserDashboard.css'; // Import scoped CSS for UserDashboard

function UserDashboard() {
  const [activeSection, setActiveSection] = useState('profile'); // Track active section
  const [notificationCount, setNotificationCount] = useState(0); // Notification count
  const navigate = useNavigate();
  const location = useLocation();

  // Sync the active section with the URL path
  useEffect(() => {
    const path = location.pathname.split('/').pop();
    setActiveSection(path || 'profile'); // Default to 'profile' if path is empty
  }, [location]);

  const handleSidebarClick = (section) => {
    setActiveSection(section); // Set the active section
    navigate(`/user-dashboard/${section}`); // Navigate to the section
  };

  const handleLogout = async () => {
    try {
      console.log('Logging out...');
      await auth.signOut(); // Call the Firebase signOut method
      navigate('/user-login'); // Redirect to login page
    } catch (err) {
      console.error('Error during logout:', err);
    }
  };

  // Fetch notification count
  useEffect(() => {
    const fetchNotificationCount = async () => {
      try {
        const user = auth.currentUser;
        if (!user) return;

        const userDocRef = doc(db, 'users', user.uid);
        const userSnapshot = await getDoc(userDocRef);

        if (userSnapshot.exists()) {
          const userData = userSnapshot.data();
          const borrowedBooks = userData.borrowedBooks || [];
          const today = new Date();

          let count = 0;

          // Check for due date notifications
          borrowedBooks.forEach((book) => {
            const dueDate = new Date(book.dueDate);
            const daysLeft = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
            if (daysLeft === 3 || daysLeft === 0) {
              count++;
            }
          });

          setNotificationCount(count); // Update the notification count
        }
      } catch (err) {
        console.error('Error fetching notification count:', err);
      }
    };

    fetchNotificationCount();
  }, []);

  return (
    <div className="user-dashboard-container">
      {/* Sidebar */}
      <UserSidebar
        onSidebarClick={handleSidebarClick}
        activeSection={activeSection}
        notificationCount={notificationCount} // Pass notification count
        onLogout={handleLogout} // Pass logout handler
      />

      {/* Main Content */}
      <div className="user-dashboard-content">
        <Routes>
          <Route path="/profile" element={<UserProfile />} />
          <Route path="/book-browsing" element={<BookBrowsing />} />
          <Route path="/borrowed-books" element={<BorrowedBooks />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/reading-history" element={<ReadingHistory />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/book/:bookId" element={<BookDetails />} /> {/* BookDetails nested route */}
          {/* Catch-all route for unmatched paths */}
          <Route
            path="*"
            element={
              <div>
                <h1>Page Not Found</h1>
              </div>
            }
          />
        </Routes>
      </div>
    </div>
  );
}

export default UserDashboard;
