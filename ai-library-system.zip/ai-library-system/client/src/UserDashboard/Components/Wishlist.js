import React, { useState, useEffect } from "react";
import { db, auth } from "../../services/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import "../Styles/Wishlist.css";

function Wishlist() {
  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWishlist = async () => {
      try {
        const user = auth.currentUser;
        if (!user) return;

        const userDoc = doc(db, "users", user.uid);
        const userSnapshot = await getDoc(userDoc);

        if (userSnapshot.exists()) {
          const userData = userSnapshot.data();
          setWishlist(userData.wishlist || []);
        }
      } catch (err) {
        console.error("Error fetching wishlist:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchWishlist();
  }, []);

  const handleRemoveFromWishlist = async (bookId) => {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const updatedWishlist = wishlist.filter((book) => book.id !== bookId);
      const userDoc = doc(db, "users", user.uid);
      await updateDoc(userDoc, { wishlist: updatedWishlist });
      setWishlist(updatedWishlist);
      alert("Book removed from wishlist!");
    } catch (err) {
      console.error("Error removing book from wishlist:", err);
    }
  };

  if (loading) {
    return <div>Loading wishlist...</div>;
  }

  return (
    <div className="user-dashboard-wishlist">
      <h2 className="wishlist-title">My Wishlist</h2>
      <div className="wishlist-items">
        {wishlist.length > 0 ? (
          wishlist.map((book) => (
            <div key={book.id} className="wishlist-item">
              <div className="wishlist-image-container">
                <img
                  src={book.imageUrl || "https://via.placeholder.com/100x130"}
                  alt={book.title}
                  className="wishlist-image"
                />
              </div>
              <h3>{book.title}</h3>
              <p>{book.author}</p>
              <button className="remove-btn" onClick={() => handleRemoveFromWishlist(book.id)}>
                Remove
              </button>
            </div>
          ))
        ) : (
          <div>No books in your wishlist.</div>
        )}
      </div>
    </div>
  );
}

export default Wishlist;
