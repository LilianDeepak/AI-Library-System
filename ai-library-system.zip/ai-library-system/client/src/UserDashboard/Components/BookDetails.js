import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { db, auth } from "../../services/firebase";
import { doc, getDoc, collection, getDocs, updateDoc } from "firebase/firestore";
import "../Styles/BookDetails.css";

function BookDetails() {
  const { bookId } = useParams();
  const [book, setBook] = useState(null);
  const [suggestedBooks, setSuggestedBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [availability, setAvailability] = useState("Available");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBookDetails = async () => {
      try {
        const bookDoc = doc(db, "books", bookId);
        const bookSnapshot = await getDoc(bookDoc);

        if (bookSnapshot.exists()) {
          const bookData = bookSnapshot.data();
          setBook(bookData);

          // Check availability
          const borrowedBy = bookData.borrowedBy || null;
          setAvailability(borrowedBy ? "Not Available" : "Available");
        } else {
          setError("Book not found");
        }
      } catch (err) {
        setError("Failed to load book details");
      } finally {
        setLoading(false);
      }
    };

    fetchBookDetails();
  }, [bookId]);

  useEffect(() => {
    const fetchSuggestedBooks = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "books"));
        const allBooks = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        const filteredBooks = allBooks.filter((b) => b.id !== bookId);
        const randomBooks = filteredBooks.sort(() => 0.5 - Math.random()).slice(0, 4);
        setSuggestedBooks(randomBooks);
      } catch (error) {
        console.error("Error fetching suggested books:", error);
      }
    };

    fetchSuggestedBooks();
  }, [bookId]);

  const handleBorrowBook = async () => {
    const user = auth.currentUser;
    if (!user) {
      alert("Please log in to borrow books.");
      return;
    }

    try {
      const userDocRef = doc(db, "users", user.uid);
      const userSnapshot = await getDoc(userDocRef);

      if (userSnapshot.exists()) {
        const userData = userSnapshot.data();
        const borrowedBooks = userData.borrowedBooks || [];

        const isAlreadyBorrowed = borrowedBooks.some((b) => b.id === bookId);
        if (isAlreadyBorrowed) {
          alert("You have already borrowed this book.");
          return;
        }

        const updatedBorrowedBooks = [
          ...borrowedBooks,
          {
            id: bookId,
            title: book.title,
            author: book.author,
            imageUrl: book.imageUrl,
            driveLink: book.driveLink,
            borrowedDate: new Date().toISOString(),
            dueDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString(),
          },
        ];

        await updateDoc(userDocRef, { borrowedBooks: updatedBorrowedBooks });
        alert("Book borrowed successfully!");

        // Update book's availability status
        const bookDocRef = doc(db, "books", bookId);
        await updateDoc(bookDocRef, { borrowedBy: user.uid });
        setAvailability("Not Available");
      } else {
        console.error("User document does not exist in Firestore.");
      }
    } catch (err) {
      console.error("Error borrowing the book:", err);
    }
  };

  const handleAddToWishlist = async () => {
    const user = auth.currentUser;
    if (!user) {
      alert("Please log in to add books to your wishlist.");
      return;
    }

    try {
      const userDocRef = doc(db, "users", user.uid);
      const userSnapshot = await getDoc(userDocRef);

      if (userSnapshot.exists()) {
        const userData = userSnapshot.data();
        const wishlist = userData.wishlist || [];

        if (wishlist.some((b) => b.id === bookId)) {
          alert("This book is already in your wishlist.");
          return;
        }

        const updatedWishlist = [
          ...wishlist,
          {
            id: bookId,
            title: book.title,
            author: book.author,
            imageUrl: book.imageUrl,
          },
        ];

        await updateDoc(userDocRef, { wishlist: updatedWishlist });
        alert("Book added to wishlist!");
      } else {
        console.error("User document does not exist in Firestore.");
      }
    } catch (err) {
      console.error("Error adding the book to the wishlist:", err);
    }
  };

  if (loading) {
    return <div>Loading book details...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="book-details-container">
      <div className="book-details-content">
        <div className="book-image-section">
          <img
            src={book.imageUrl || "https://via.placeholder.com/150"}
            alt={book.title}
            className="book-details-image"
          />
        </div>
        <div className="book-details-section">
          <div className="book-header">
            <h1 className="book-title">{book.title}</h1>
            <span className={`availability ${availability === "Available" ? "available" : "not-available"}`}>
              {availability}
            </span>
            <button className="favorite-btn" onClick={handleAddToWishlist}>
              ❤️ Favorite
            </button>
          </div>
          <p className="book-author">by {book.author}</p>
          <p className="book-description">{book.description}</p>
          <button
            className="borrow-btn"
            onClick={handleBorrowBook}
            disabled={availability === "Not Available"}
          >
            Borrow
          </button>
        </div>
      </div>
      <div className="suggested-books-section">
        <h2 className="suggested-title">Suggested for You</h2>
        <div className="suggested-books-list">
          {suggestedBooks.map((suggestedBook) => (
            <div
              key={suggestedBook.id}
              className="suggested-book-item"
              onClick={() => navigate(`/user-dashboard/book/${suggestedBook.id}`)}
            >
              <div className="suggested-book-image-container">
                <img
                  src={suggestedBook.imageUrl || "https://via.placeholder.com/100x130"}
                  alt={suggestedBook.title}
                  className="suggested-book-image"
                />
              </div>
              <h3>{suggestedBook.title}</h3>
              <p>{suggestedBook.author}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default BookDetails;
