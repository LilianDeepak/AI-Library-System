import React, { useState, useEffect } from 'react';
import { db, auth } from '../../services/firebase'; // Firebase setup
import { doc, getDoc, updateDoc } from 'firebase/firestore'; // Firestore functions
import { onAuthStateChanged } from 'firebase/auth';
import '../Styles/UserProfile.css';

function UserProfile() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    profession: '',
    phone: '',
  });
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true); // Add loading state
  const [error, setError] = useState(null); // Add error state

  useEffect(() => {
    const fetchUserData = async (user) => {
      const userId = user.uid;
      const userDoc = doc(db, 'users', userId);

      try {
        const userSnapshot = await getDoc(userDoc);
        if (userSnapshot.exists()) {
          setFormData(userSnapshot.data());
        } else {
          setError('User data not found in Firestore!');
        }
      } catch (error) {
        setError('Error fetching user data from Firestore');
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        fetchUserData(user);
      } else {
        setError('No authenticated user found!');
        setLoading(false);
      }
    });

    // Cleanup the listener
    return () => unsubscribe();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSaveChanges = async () => {
    const user = auth.currentUser;
    if (user) {
      const userId = user.uid;
      const userDoc = doc(db, 'users', userId);

      try {
        await updateDoc(userDoc, formData);
        setIsEditing(false);
        alert('Profile updated successfully!');
      } catch (error) {
        console.error('Error updating profile in Firestore:', error);
      }
    } else {
      console.error('No authenticated user found!');
    }
  };

  if (loading) {
    return <div>Loading...</div>; // Show a loading spinner or message
  }

  if (error) {
    return <div>{error}</div>; // Show error message
  }

  return (
    <div className="user-profile-container">
      <h2 className="profile-title">Edit Personal Info</h2>
      <form className="profile-form">
        <div className="form-group">
          <label className="profile-label">Full Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className="profile-input"
            disabled={!isEditing}
          />
        </div>

        <div className="form-group">
          <label className="profile-label">Email</label>
          <input
            type="text"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className="profile-input"
            disabled={!isEditing}
          />
        </div>

        <div className="form-group">
          <label className="profile-label">Profession</label>
          <input
            type="text"
            name="profession"
            value={formData.profession}
            onChange={handleInputChange}
            className="profile-input"
            disabled={!isEditing}
          />
        </div>

        <div className="form-group">
          <label className="profile-label">Phone</label>
          <input
            type="text"
            name="phone"
            value={formData.phone}
            onChange={handleInputChange}
            className="profile-input"
            disabled={!isEditing}
          />
        </div>

        {!isEditing ? (
          <button type="button" onClick={() => setIsEditing(true)}>
            Edit
          </button>
        ) : (
          <button type="button" onClick={handleSaveChanges}>
            Save Changes
          </button>
        )}
      </form>
    </div>
  );
}

export default UserProfile;
