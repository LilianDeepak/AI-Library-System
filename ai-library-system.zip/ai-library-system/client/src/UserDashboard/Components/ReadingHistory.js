import React, { useState, useEffect } from "react";
import { db, auth } from "../../services/firebase"; // Firebase setup
import { doc, getDoc } from "firebase/firestore"; // Firestore functions
import "../Styles/ReadingHistory.css";

function ReadingHistory() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReadingHistory = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          alert("Please log in to view your reading history.");
          return;
        }

        const userDoc = doc(db, "users", user.uid);
        const userSnapshot = await getDoc(userDoc);

        if (userSnapshot.exists()) {
          const userData = userSnapshot.data();
          setHistory(userData.readingHistory || []);
        }
      } catch (err) {
        console.error("Error fetching reading history:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchReadingHistory();
  }, []);

  if (loading) {
    return <div>Loading reading history...</div>;
  }

  return (
    <div className="user-dashboard-history">
      <h2 className="history-title">Reading History</h2>
      <div className="history-list">
        {history.length > 0 ? (
          history.map((book) => (
            <div key={book.id} className="history-item">
              <div className="history-image-container">
                <img
                  src={book.imageUrl || "https://via.placeholder.com/130x200"}
                  alt={book.title}
                  className="history-image"
                />
              </div>
              <h3>{book.title}</h3>
              <p>Read on: {new Date(book.readDate).toLocaleDateString()}</p>
            </div>
          ))
        ) : (
          <div>No books in reading history.</div>
        )}
      </div>
    </div>
  );
}

export default ReadingHistory;
