import React from 'react';
import PropTypes from 'prop-types';
import '../Styles/UserSidebar.css'; // Import CSS

function UserSidebar({ onSidebarClick, activeSection, notificationCount, onLogout }) {
  const menuItems = [
    { key: 'profile', label: 'User Profile' },
    { key: 'book-browsing', label: 'Browse Books' },
    { key: 'borrowed-books', label: 'Borrowed Books' },
    { key: 'wishlist', label: 'Wishlist' },
    { key: 'reading-history', label: 'Reading History' },
    { key: 'notifications', label: 'Notifications' },
  ];

  const handleLogoutClick = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      onLogout(); // Call the logout function if confirmed
    }
  };

  return (
    <div className="user-dashboard-sidebar">
      <h2 className="sidebar-title">Dashboard</h2>
      <ul className="sidebar-menu">
        {menuItems.map((item) => (
          <li
            key={item.key}
            className={`sidebar-item ${activeSection === item.key ? 'active' : ''}`}
            onClick={() => onSidebarClick(item.key)}
          >
            {item.label}
            {item.key === 'notifications' && notificationCount > 0 && (
              <span className="notification-badge">{notificationCount}</span>
            )}
          </li>
        ))}
        {/* Logout Option */}
        <li
          className="sidebar-item logout-item"
          onClick={handleLogoutClick} // Trigger the logout confirmation
        >
          Logout
        </li>
      </ul>
    </div>
  );
}

UserSidebar.propTypes = {
  onSidebarClick: PropTypes.func.isRequired,
  activeSection: PropTypes.string.isRequired,
  notificationCount: PropTypes.number, // Notification count prop
  onLogout: PropTypes.func.isRequired, // Logout function prop
};

UserSidebar.defaultProps = {
  notificationCount: 0, // Default to 0 if no count is provided
};

export default UserSidebar;
