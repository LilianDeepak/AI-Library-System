import React, { useState, useEffect } from "react";
import { db, auth } from "../../services/firebase";
import {
  doc,
  getDoc,
  query,
  collection,
  onSnapshot,
} from "firebase/firestore";
import "../Styles/Notifications.css";

function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0); // Unread notifications count

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          alert("Please log in to view notifications.");
          return;
        }

        const userDocRef = doc(db, "users", user.uid);
        const userSnapshot = await getDoc(userDocRef);

        if (userSnapshot.exists()) {
          const userData = userSnapshot.data();
          const borrowedBooks = userData.borrowedBooks || [];
          const today = new Date();

          const newNotifications = [];

          // Check for due date notifications
          borrowedBooks.forEach((book) => {
            const dueDate = new Date(book.dueDate);
            const daysLeft = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));

            if (daysLeft === 3) {
              newNotifications.push({
                id: `${book.id}-due-soon`,
                message: `Your borrowed book "${book.title}" is due in 3 days!`,
              });
            } else if (daysLeft === 0) {
              newNotifications.push({
                id: `${book.id}-due-today`,
                message: `Your borrowed book "${book.title}" is due today! Please return it on time.`,
              });
            }
          });

          // Check for new books in the collection with status 'new'
          const booksQuery = query(collection(db, "books"));
          onSnapshot(booksQuery, (snapshot) => {
            const newBookNotifications = snapshot.docs
              .filter((doc) => doc.data().status === "new") // Only books with status 'new'
              .map((doc) => ({
                id: `${doc.id}-new-book`,
                message: `You may also like "${doc.data().title}"! Explore our new collection.`,
              }));

            // Add the new book notifications to the list
            setNotifications((prev) => [...prev, ...newNotifications, ...newBookNotifications]);
            setUnreadCount(newNotifications.length + newBookNotifications.length);
          });
        }
      } catch (err) {
        console.error("Error fetching notifications:", err);
      }
    };

    fetchNotifications();
  }, []);

  return (
    <div className="user-dashboard-notifications">
      <h2 className="notifications-title">
        Notifications
        {unreadCount > 0 && (
          <span className="notification-badge">({unreadCount})</span>
        )}
      </h2>
      <div className="notifications-list">
        {notifications.length > 0 ? (
          notifications.map((notification) => (
            <div key={notification.id} className="notification-item">
              <p>{notification.message}</p>
            </div>
          ))
        ) : (
          <div>No notifications at the moment.</div>
        )}
      </div>
    </div>
  );
}

export default Notifications;
