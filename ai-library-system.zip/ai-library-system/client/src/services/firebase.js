// Import necessary functions from Firebase
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';  // Import Firestore
import { getDatabase } from 'firebase/database';  // For Realtime Database if needed

// Firebase configuration - replace with your Firebase project credentials
const firebaseConfig = {
  apiKey: "AIzaSyDjcjOxxTAiQCaoHlYg3wdhKmM_CXOShEs",
  authDomain: "librarysystem-50571.firebaseapp.com",
  databaseURL: "https://librarysystem-50571-default-rtdb.firebaseio.com",
  projectId: "librarysystem-50571",
  storageBucket: "librarysystem-50571.appspot.com",
  messagingSenderId: "604696579139",
  appId: "1:604696579139:web:a048975fc29d0a2248d8f6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Auth
const auth = getAuth(app);

// Initialize Firestore for cloud database
const db = getFirestore(app);  // Initialize Firestore

// Initialize Firebase Realtime Database (if you need it later)
const realtimeDb = getDatabase(app);  // Realtime Database initialization

// Export auth and db so they can be used in other parts of the application
export { auth, db, realtimeDb };  // Export db (Firestore) and realtimeDb
